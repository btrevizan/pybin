from .pybin import StructFile
