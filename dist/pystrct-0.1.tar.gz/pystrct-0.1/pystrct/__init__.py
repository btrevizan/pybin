from .pystrct import StructFile
